package teamproject;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTable;

public class membership extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTable table;
	
	String person[] = {"ȸ�����̵�","�̸�","�������"};
	String header[] = {"ȸ�����̵�","�̸�","�������","�뿩��������"};
	String contents[][] = {
			{"123","�����","1918�� 5�� 15��","0"},
			{"124","ȣ����","1985�� 2�� 5��","3"},
			{"125","�����","1992�� 7�� 8��","2"},
			{"126","������","1981�� 2�� 25��","1"}
	};
	
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					membership frame = new membership();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public membership() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JComboBox comboBox = new JComboBox(person);
		
		comboBox.setToolTipText("\uD68C\uC6D0\uC544\uC774\uB514");
		comboBox.setBounds(75, 46, 105, 47);
		contentPane.add(comboBox);
		
		textField = new JTextField();
		textField.setText("\uB0B4\uC6A9\uC744 \uC785\uB825\uD574\uC8FC\uC138\uC694.");
		textField.setBounds(220, 46, 372, 47);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("\uAC80\uC0C9");
		btnNewButton.setBounds(625, 58, 105, 28);
		contentPane.add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(75, 137, 655, 374);
		contentPane.add(scrollPane);
		
		table = new JTable(contents,header);
		scrollPane.setViewportView(table);
		
		JButton btnNewButton_1 = new JButton("\uCD94\uAC00");
		btnNewButton_1.setBounds(85, 521, 97, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("\uC0AD\uC81C");
		btnNewButton_2.setBounds(220, 521, 97, 23);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("\uCDE8\uC18C");
		btnNewButton_3.setBounds(633, 521, 97, 23);
		contentPane.add(btnNewButton_3);
	}
}
