package teamproject;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Rectangle;
import javax.swing.JButton;
import java.awt.GridLayout;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.SystemColor;
import java.awt.Font;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.LineBorder;

public class main extends JFrame {

	private JPanel contentPane;
	private JTextField maintf;
	private JTable table;
	
	String header[] = {"ȸ����ȣ","�̸�","����","�������","����","�ڵ�����ȣ","�뿩��������"};
	String contents[][] = {
			{"123","�����","100","1918�� 5�� 15��","����","0104561234","0"},
			{"124","ȣ����","34","1985�� 2�� 5��","����","0101234567","3"},
			{"125","�����","27","1992�� 7�� 8��","����","0109873246","2"},
			{"126","������","38","1981�� 2�� 25��","����","0106547321","1"},
			{"127","�迬��","27","1990�� 9�� 5��","����","0106241487","1"}
			
	};

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					main frame = new main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public main() {
		setTitle("main");
		setBounds(new Rectangle(0, 0, 800, 1000));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(380, 40, 800, 800);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.window);
		contentPane.setBounds(new Rectangle(0, 0, 800, 1000));
		contentPane.setBorder(null);
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JComboBox maincomboBox = new JComboBox();
		maincomboBox.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		maincomboBox.setBounds(58, 117, 110, 30);
		contentPane.add(maincomboBox);
		
		maintf = new JTextField();
		maintf.setBorder(new LineBorder(Color.BLACK));
		maintf.setBounds(203, 117, 419, 30);
		contentPane.add(maintf);
		maintf.setColumns(10);
		
		JButton mainsearch = new JButton("");
		mainsearch.setBackground(Color.WHITE);
		mainsearch.setIcon(new ImageIcon(main.class.getResource("/teamproject/imagebt/\uAC80\uC0C9.jpg")));
		mainsearch.setBorder(null);
		mainsearch.setForeground(SystemColor.inactiveCaptionText);
		mainsearch.setFont(new Font("HY������M", Font.PLAIN, 12));
		mainsearch.setBounds(677, 117, 76, 30);
		contentPane.add(mainsearch);
		
		JButton rent = new JButton("");
		rent.setIcon(new ImageIcon(main.class.getResource("/teamproject/imagebt/\uB300\uC5EC.jpg")));
		rent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		rent.setBorder(null);
		rent.setBackground(Color.WHITE);
		rent.setForeground(Color.BLACK);
		rent.setFont(new Font("���ĵ���", Font.BOLD, 15));
		rent.setBounds(25, 32, 93, 30);
		contentPane.add(rent);
		
		JButton returns = new JButton("");
		returns.setBackground(Color.WHITE);
		returns.setBorder(null);
		returns.setIcon(new ImageIcon(main.class.getResource("/teamproject/imagebt/\uBC18\uB0A9.jpg")));
		returns.setForeground(Color.WHITE);
		returns.setFont(new Font("HY������M", Font.PLAIN, 12));
		returns.setBounds(175, 32, 93, 30);
		contentPane.add(returns);
		
		JButton members = new JButton("");
		members.setBackground(Color.WHITE);
		members.setBorder(new EmptyBorder(0, 0, 0, 0));
		members.setIcon(new ImageIcon(main.class.getResource("/teamproject/imagebt/\uD68C\uC6D0\uC815\uBCF4.jpg")));
		members.setForeground(SystemColor.inactiveCaptionText);
		members.setFont(new Font("HY������M", Font.PLAIN, 12));
		members.setBounds(330, 32, 103, 30);
		contentPane.add(members);
		
		JButton bookmang = new JButton("");
		bookmang.setBackground(Color.WHITE);
		bookmang.setBorder(new EmptyBorder(0, 0, 0, 0));
		bookmang.setIcon(new ImageIcon(main.class.getResource("/teamproject/imagebt/\uB3C4\uC11C\uAD00\uB9AC.jpg")));
		bookmang.setForeground(SystemColor.inactiveCaptionText);
		bookmang.setFont(new Font("HY������M", Font.PLAIN, 12));
		bookmang.setBounds(497, 32, 103, 30);
		contentPane.add(bookmang);
		
		JButton statis = new JButton("");
		statis.setBackground(Color.WHITE);
		statis.setBorder(new EmptyBorder(0, 0, 0, 0));
		statis.setIcon(new ImageIcon(main.class.getResource("/teamproject/imagebt/\uD1B5\uACC4.jpg")));
		statis.setForeground(SystemColor.inactiveCaptionText);
		statis.setFont(new Font("HY������M", Font.PLAIN, 12));
		statis.setBounds(667, 32, 93, 30);
		contentPane.add(statis);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(24, 196, 736, 556);
		contentPane.add(scrollPane);
		
		JPanel panel = new JPanel();
		scrollPane.setViewportView(panel);
		panel.setLayout(null);
		
		table = new JTable(contents,header);
		table.setBounds(12, 549, 710, -548);
		scrollPane.setViewportView(table);
		
	}
}
